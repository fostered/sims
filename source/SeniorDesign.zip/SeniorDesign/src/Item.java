
public class Item {
	
	private int id = 0;
	private String name = "";
	private boolean inStock = true;
	private long whoHas = -1;
	
	public Item(int id, String name) {
		this.name = name;
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getID() {
		return id;
	}
	
	boolean inStock() {
		return inStock;
	}
	
	void rentItem(long personId) {
		inStock = false;
		whoHas = personId;
	}
	
	void returnItem() {
		inStock = true;
		whoHas = 0;
	}
	
	long whoHas() {
		return whoHas;
	}

}
