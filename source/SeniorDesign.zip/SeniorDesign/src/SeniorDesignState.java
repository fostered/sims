
/*
 * This file is public domain.
 *
 * SWIRLDS MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SWIRLDS SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES SUFFERED AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.swirlds.platform.Address;
import com.swirlds.platform.AddressBook;
import com.swirlds.platform.FCDataInputStream;
import com.swirlds.platform.FCDataOutputStream;
import com.swirlds.platform.FastCopyable;
import com.swirlds.platform.Platform;
import com.swirlds.platform.SwirldState;
import com.swirlds.platform.Utilities;

/**
 * This holds the current state of the swirld. For this simple "hello swirld" code, each transaction is just
 * a string, and the state is just a list of the strings in all the transactions handled so far, in the
 * order that they were handled.
 */
public class SeniorDesignState implements SwirldState {
	/**
	 * The shared state is just a list of the strings in all transactions, listed in the order received
	 * here, which will eventually be the consensus order of the community.
	 */
	private List<String> strings = new ArrayList<String>();
	/** names and addresses of all members */
	private AddressBook addressBook;

	/** @return all the strings received so far from the network */
	public synchronized List<String> getStrings() {
		return strings;
	}

	/** @return all the strings received so far from the network, concatenated into one */
	public synchronized String getReceived() {
		return strings.toString();
	}

	/** @return the same as getReceived, so it returns the entire shared state as a single string */
	public synchronized String toString() {
		return strings.toString();
	}
	
	private String[] itemNames = {
			"Charger", "Laptop", "Phone", "Fork",
			"Pizza", "Chair", "Soap", "Plate",
			"Fan", "Towel", "Sock", "Crate"
		};
	
	private String[] inventory = new String[itemNames.length];
	private int[] isAvailable = new int[itemNames.length];
	private long[] renterIds = new long[itemNames.length];

	public synchronized String[] getItems(boolean ifAvailable) {
		int count = 0;
		String[] items = new String[inventory.length];
		for (int i = 0; i < inventory.length; i++) {
			if (isAvailable[i] == 1)
				items[count++] = inventory[i];
		}
		return items;
	}

	/////////////////////////////////////////////////////////////////////

	@Override
	public synchronized AddressBook getAddressBookCopy() {
		return addressBook.copy();
	}

	@Override
	public synchronized FastCopyable copy() {
		SeniorDesignState copy = new SeniorDesignState();
		copy.copyFrom(this);
		return copy;
	}

	@Override
	public synchronized void copyTo(FCDataOutputStream outStream) {
		try {
			Utilities.writeStringArray(outStream, inventory);
			Utilities.writeIntArray(outStream, isAvailable);
			Utilities.writeLongArray(outStream, renterIds);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public synchronized void copyFrom(FCDataInputStream inStream) {
		try {
			
			inventory = Utilities.readStringArray(inStream);
			
			isAvailable = Utilities.readIntArray(inStream);
			
			renterIds = Utilities.readLongArray(inStream);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public synchronized void copyFrom(SwirldState oldState) {
		SeniorDesignState old = (SeniorDesignState) oldState;
		
		inventory = old.inventory;
		isAvailable = old.isAvailable;
		renterIds = old.renterIds;
		
		addressBook = old.addressBook.copy();
	}
	
	public static enum CommandType {
		RENT, RETURN, ADD // run slow/fast or broadcast a bid/ask
	};
	
	public static enum ItemType {
		CHARGER, LAPTOP, PHONE, FORK, 
		PIZZA, CHAIR, SOAP, PLATE,
		FAN, TOWEL, SOCK, CRATE // run slow/fast or broadcast a bid/ask
	};
	
	public synchronized String getItem(int index) {
		return inventory[index];
	}

	@Override
	public synchronized void handleTransaction(long id, boolean consensus,
			Instant timestamp, byte[] transaction, Address address) {
		if (!consensus)
			return;
		if (transaction[0] == CommandType.ADD.ordinal() && inventory[transaction[1]] == null) {
			inventory[transaction[1]] = itemNames[transaction[1]];
		} else if (transaction[0] == CommandType.RENT.ordinal()) {
				if (isAvailable[transaction[1]] == 1) {
					isAvailable[transaction[1]] = 0;
					renterIds[transaction[1]] = id;
				}
		} else if (transaction[0] == CommandType.RETURN.ordinal()) {
			if (renterIds[transaction[1]] == id) {
				isAvailable[transaction[1]] = 1;
				renterIds[transaction[1]] = -1;
			}
		}
	}
	
	public long[] getRenters() {
		return renterIds;
	}

	@Override
	public void noMoreTransactions() {
	}

	@Override
	public synchronized void init(Platform platform, AddressBook addressBook) {
		this.addressBook = addressBook;
	}
}